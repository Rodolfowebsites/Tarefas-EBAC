package oo.composicao;

public class CompraTeste {

    public static void main(String[] args) {

        Compra c1 = new Compra();
        c1.cliente = "João Pedro";
        c1.itens.add(new Item("Caneta", 2, 8.50));
        c1.itens.add(new Item("Borracha", 1, 3.50));
        c1.itens.add(new Item("Caderno", 1, 60));

        System.out.println(c1.itens.size());
        System.out.println(c1.getValorTotal());
    }
}
